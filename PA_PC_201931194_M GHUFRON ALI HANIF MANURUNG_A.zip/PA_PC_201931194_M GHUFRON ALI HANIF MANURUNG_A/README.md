
# Deteksi Plat Nomer

#### M GHUFRON ALI HANIF MANURUNG (201931194)

Ini adalah panduan lengkap yang menjelaskan langkah-langkah untuk mendeteksi plat nomor kendaraan menggunakan OpenCV dan Python di lingkungan Jupyter Notebook. Panduan ini akan memberikan Anda pemahaman yang jelas tentang bagaimana melakukan deteksi plat nomor kendaraan pada gambar kendaraan menggunakan algoritma pengolahan citra.

## Prasyarat

Sebelum memulai, pastikan Anda memenuhi prasyarat berikut:

- Python 3.x terinstal di sistem Anda.
- Jupyter Notebook terinstal di sistem Anda.
- Package OpenCV telah diinstal. Jika Anda belum menginstalnya, Anda dapat menggunakan perintah berikut untuk menginstalnya:

```shell
pip install opencv-python
```

## Langkah-langkah Deteksi Plat Nomor Kendaraan

Berikut adalah langkah-langkah yang perlu Anda ikuti untuk mendeteksi plat nomor kendaraan menggunakan OpenCV dan Python di Jupyter Notebook:

### 1. Buka Jupyter Notebook

Buka Jupyter Notebook pada sistem Anda.

### 2. Buat Notebook Baru

Buat notebook baru dengan mengklik tombol "New" di Jupyter Notebook dan pilih kernel Python.

### 3. Impor Library yang Diperlukan

Impor library yang diperlukan untuk deteksi plat nomor kendaraan. Jalankan sel berikut di notebook Anda:

```python
import cv2
import numpy as np
import matplotlib.pyplot as plt
```

Ini akan mengimpor library OpenCV, NumPy, dan Matplotlib yang diperlukan untuk pemrosesan citra dan visualisasi.

### 4. Baca Gambar Kendaraan

Baca gambar kendaraan yang akan Anda deteksi. Anda dapat menggunakan perintah berikut untuk membaca gambar:

```python
image = cv2.imread('path/to/vehicle/image.jpg')
```

Pastikan untuk mengganti `'path/to/vehicle/image.jpg'` dengan lokasi dan nama file gambar kendaraan yang sebenarnya.

### 5. Konversi ke Skala Abu-Abu

Konversi gambar ke dalam skala abu-abu. Ini dapat dilakukan dengan menggunakan perintah berikut:

```python
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
```

### 6. Deteksi Tepi

Terapkan operasi deteksi tepi pada gambar. Ini membantu dalam menemukan tepi plat nomor. Anda dapat menggunakan Algoritma Canny untuk tujuan ini:

```python
edges = cv2.Canny(gray, 50, 150)
```

Nilai ambang (threshold) 50 dan 150 dapat disesuaikan sesuai kebutuhan.

### 7. Temukan Kontur

Temukan kontur pada gambar menggunakan fungsi `cv2.findContours()`:

```python
contours, hierarchy = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
```

### 8. Pilih Kontur Terbesar

Pilih kontur dengan luas terbesar yang kemungkinan besar adalah plat nomor kendaraan. Anda dapat melakukan ini dengan memeriksa luas setiap kontur dan memilih yang terbesar:

```python
largest_contour = max(contours, key=cv2.contourArea)
```

### 9. Gambar

 Kotak Persegi Panjang

Gambar kotak persegi panjang di sekitar plat nomor menggunakan fungsi `cv2.rectangle()`:

```python
x, y, w, h = cv2.boundingRect(largest_contour)
cv2.rectangle(image, (x, y), (x + w, y + h), (0, 255, 0), 2)
```

### 10. Tampilkan Gambar Hasil

Tampilkan gambar hasil deteksi dengan menggunakan perintah berikut:

```python
plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
plt.axis('off')
plt.show()
```

### 11. Jalankan Kode

Jalankan seluruh kode di notebook Anda dan amati hasilnya. Anda akan melihat gambar kendaraan dengan kotak persegi panjang yang mengelilingi plat nomor kendaraan.

## Kesimpulan

Dalam panduan ini, Anda telah belajar langkah-langkah untuk mendeteksi plat nomor kendaraan menggunakan OpenCV dan Python di lingkungan Jupyter Notebook. Dengan mengikuti langkah-langkah ini, Anda dapat melakukan deteksi plat nomor kendaraan pada gambar kendaraan Anda sendiri. Selamat mencoba!